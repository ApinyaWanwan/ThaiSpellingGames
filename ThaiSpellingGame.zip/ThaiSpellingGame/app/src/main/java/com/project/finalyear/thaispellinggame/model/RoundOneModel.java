package com.project.finalyear.thaispellinggame.model;

/**
 * Created by kamonwan on 11/25/2017.
 */

public class RoundOneModel {
    public   String correctAnswer;

    public RoundOneModel() {

    }

    public RoundOneModel(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

}
