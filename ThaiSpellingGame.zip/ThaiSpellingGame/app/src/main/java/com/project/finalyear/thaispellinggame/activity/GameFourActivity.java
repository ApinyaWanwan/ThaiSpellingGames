package com.project.finalyear.thaispellinggame.activity;


import android.content.ClipData;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.project.finalyear.thaispellinggame.R;


public class GameFourActivity extends AppCompatActivity implements View.OnTouchListener{

    Button btnVocab;
    LinearLayout leftLinear, rightLinear;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_four);

        //this.deleteDatabase("TFG_database.db");

        btnVocab = (Button)findViewById(R.id.btnVocab);
        btnVocab.setOnTouchListener(this);

        leftLinear = (LinearLayout)findViewById(R.id.drop_left);
        rightLinear = (LinearLayout)findViewById(R.id.drop_right);

        leftLinear.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {
                final int action = event.getAction();
                switch (action){
                    case DragEvent.ACTION_DRAG_STARTED:
                        break;
                    case DragEvent.ACTION_DRAG_EXITED:

                        break;
                    case DragEvent.ACTION_DRAG_ENTERED:
                        final Animation animMoveLeft = AnimationUtils.loadAnimation(GameFourActivity.this, R.anim.move_left);
                        btnVocab.startAnimation(animMoveLeft);

                        break;
                    case DragEvent.ACTION_DROP:
                        return (true);
                    case DragEvent.ACTION_DRAG_ENDED:
                        return (true);
                    default:
                        break;
                }
                return true;
            }
        });

        rightLinear.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {
                final int action = event.getAction();
                switch (action){
                    case DragEvent.ACTION_DRAG_STARTED:
                        break;
                    case DragEvent.ACTION_DRAG_EXITED:
                        break;
                    case DragEvent.ACTION_DRAG_ENTERED:
                        final Animation animMoveRight = AnimationUtils.loadAnimation(GameFourActivity.this, R.anim.move_right);
                        btnVocab.startAnimation(animMoveRight);
                        break;
                    case DragEvent.ACTION_DROP:
                        return (true);
                    case DragEvent.ACTION_DRAG_ENDED:
                        return (true);
                    default:
                        break;
                }
                return true;

            }
        });

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            ClipData data = ClipData.newPlainText("","");
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
            v.startDrag(data, shadow, v, 0);
        }
        return false;
    }
}
