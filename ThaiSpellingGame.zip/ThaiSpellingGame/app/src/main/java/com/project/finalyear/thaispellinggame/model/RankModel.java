package com.project.finalyear.thaispellinggame.model;

public class RankModel {
    public String name;
    public String score;
    public String level;
    public String rank;

    public RankModel() {

    }


    public RankModel(String name, String score, String level, String rank) {
        this.name = name;
        this.score = score;
        this.level = level;
        this.rank = rank;
    }
}
