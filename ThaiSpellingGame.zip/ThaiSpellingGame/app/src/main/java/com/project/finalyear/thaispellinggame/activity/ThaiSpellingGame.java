package com.project.finalyear.thaispellinggame.activity;

import android.app.Application;

import com.firebase.client.Firebase;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Namwan on 1/17/2018.
 */

public class ThaiSpellingGame extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Firebase.getDefaultConfig().setPersistenceEnabled(true);

        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

    }
}
