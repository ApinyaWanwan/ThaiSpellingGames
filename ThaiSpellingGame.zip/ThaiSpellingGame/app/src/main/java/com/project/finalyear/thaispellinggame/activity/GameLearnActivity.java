package com.project.finalyear.thaispellinggame.activity;


import android.content.ClipData;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.project.finalyear.thaispellinggame.R;
import com.project.finalyear.thaispellinggame.model.GameLearnModel;

import java.util.ArrayList;
import java.util.Random;

public class GameLearnActivity extends AppCompatActivity implements View.OnTouchListener {

    Button[] btn = new Button[9];
    Button btnPlayAgain;
    LinearLayout dragLinear,basketLinear;
    TextView tvQuestion;
    int sum = 0, countToFin = 0, game_over = 0;
    String section;
    ImageView happy, sad;
    ArrayList<String> questionList = new ArrayList<>();
    Random random = new Random();

    private ArrayList<GameLearnModel> list;
    private ArrayList<String> type;
    private static final String FIREBASE_URL = "https://thaispellinggame-28cfe.firebaseio.com/";
    private int currentGameLearnIndex;
    private DatabaseReference mDatabase;
    private FirebaseDatabase firebaseDatabase;
    private Firebase mRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_learn);
        Firebase.setAndroidContext(this);


        String url = "/data/data/com.project.finalyear.thaispellinggame/databases/TFG_database.db";
        this.deleteDatabase(url);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("Game_Learn");
        mDatabase.keepSynced(true);

        btn[0] = (Button) findViewById(R.id.one);
        btn[1] = (Button) findViewById(R.id.two);
        btn[2] = (Button) findViewById(R.id.three);
        btn[3] = (Button) findViewById(R.id.four);
        btn[4] = (Button) findViewById(R.id.five);
        btn[5] = (Button) findViewById(R.id.six);
        btn[6] = (Button) findViewById(R.id.seven);
        btn[7] = (Button) findViewById(R.id.eight);
        btn[8] = (Button) findViewById(R.id.nine);
        dragLinear = (LinearLayout) findViewById(R.id.drag_it_linear);
        basketLinear = (LinearLayout) findViewById(R.id.drop_here_linear);
        tvQuestion = (TextView) findViewById(R.id.tv_question);
        btnPlayAgain = (Button) findViewById(R.id.btnPlayAgain);

        pullData();


        final Animation animTranslate = AnimationUtils.loadAnimation(this, R.anim.translate);
        basketLinear.startAnimation(animTranslate);


        final Animation animShake = AnimationUtils.loadAnimation(this, R.anim.shake);
        for (int i=0; i<btn.length; i++) {
            btn[i].startAnimation(animShake);
        }

        final Animation animscale = AnimationUtils.loadAnimation(this, R.anim.scale);
        happy = (ImageView) findViewById(R.id.happy);
        sad = (ImageView) findViewById(R.id.sad);

        dragLinear.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {
                // TODO Auto-generated method stub
                final int action = event.getAction();
                switch (action) {
                    case DragEvent.ACTION_DRAG_STARTED:
                        // Executed after startDrag() is called.
                        break;
                    case DragEvent.ACTION_DRAG_EXITED:

                        if (checkAnswer(section)) {
                            game_over++;
                            View view = (View) event.getLocalState();
                            view.setVisibility(View.INVISIBLE);

                            MediaPlayer correct = MediaPlayer.create(GameLearnActivity.this, R.raw.correct);
                            correct.start();
                            happy.setVisibility(View.VISIBLE);
                            happy.startAnimation(animscale);
                            happy.setVisibility(View.INVISIBLE);

                            if (game_over == 9) {
                                //Toast.makeText(GameLearnActivity.this, "Game Over", Toast.LENGTH_SHORT).show();
                                final Animation animShake = AnimationUtils.loadAnimation(GameLearnActivity.this, R.anim.shake);
                                tvQuestion.setText("");

                                btnPlayAgain.setVisibility(View.VISIBLE);
                                btnPlayAgain.startAnimation(animShake);

                                btnPlayAgain.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(GameLearnActivity.this, GameLearnActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                            }
                        } else {
                            MediaPlayer wrong = MediaPlayer.create(GameLearnActivity.this, R.raw.wrong);
                            wrong.start();
                            sad.setVisibility(View.VISIBLE);
                            sad.startAnimation(animscale);
                            sad.setVisibility(View.INVISIBLE);
                        }

                        break;
                    case DragEvent.ACTION_DRAG_ENTERED:
                        // Executed after the Drag Shadow enters the drop area
                        break;
                    case DragEvent.ACTION_DROP:
                        //Executed when user drops the data
                        return (true);
                    case DragEvent.ACTION_DRAG_ENDED:
                        return (true);
                    default:
                        break;
                }
                return true;
            }
        });

        for (int i = 0; i < 9; i++) {
            btn[i].setOnTouchListener(this);
        }

    }

    private void pullData() {
        mRef = new Firebase(FIREBASE_URL);
        mRef = mRef.child("Game_Learn");

        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list = new ArrayList<GameLearnModel>();
                for (DataSnapshot dsp : dataSnapshot.getChildren()) {
                    list.add(dsp.getValue(GameLearnModel.class));
                }
                currentGameLearnIndex = 0;
                displayData(currentGameLearnIndex);

                randomQuestion();
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        };

        mRef.addValueEventListener(listener);

    }

    private void randomQuestion() {

        if (questionList.size() != 0) {
            int index = random.nextInt(questionList.size());
            String typeSpell = (questionList.get(index));
            tvQuestion.setText(typeSpell);
            questionList.remove(index);

            final Animation animShake = AnimationUtils.loadAnimation(this, R.anim.shake);
            tvQuestion.setAnimation(animShake);



            //count for random question
            for (int i = 0; i < type.size(); i++) {
                if (type.get(i).equals(tvQuestion.getText())) {
                    sum++;
                    Log.v("mySum" + type.get(i), String.valueOf(sum));
                }
            }
            if (sum == 0)
                randomQuestion();
        }else {  }
    }


    private void displayData(int idx) {
        // add questions
        questionList.add("แม่กก");
        questionList.add("แม่กด");
        questionList.add("แม่กบ");
        questionList.add("แม่กน");
        questionList.add("แม่กม");
        questionList.add("แม่กง");
        questionList.add("แม่เกย");
        questionList.add("แม่เกอว");

        // random vocabulary
        type = new ArrayList<String>();

        for (int i = 0; i < 9; i++) {
            //Random random = new Random();
            int index = random.nextInt(list.size());
            btn[i].setText(list.get(index).getWord());

            String text = list.get(index).getType();
            type.add(i, text);
            list.remove(index);
        }

    }

    private boolean checkAnswer(String type) {

        if (type.equals(tvQuestion.getText())) {
            countToFin++; // ถ้าตอบถูกให้บวกค่าเพิ่ม

            if (countToFin == sum) {
                // set count and sum = 0 to start new question
                countToFin = 0;
                sum = 0;
                randomQuestion();
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            switch (v.getId()) {
                case R.id.one:
                    section = type.get(0);
                    setButtonDrag(v);
                    break;
                case R.id.two:
                    section = type.get(1);
                    setButtonDrag(v);
                    break;
                case R.id.three:
                    section = type.get(2);
                    setButtonDrag(v);
                    break;
                case R.id.four:
                    section = type.get(3);
                    setButtonDrag(v);
                    break;
                case R.id.five:
                    section = type.get(4);
                    setButtonDrag(v);
                    break;
                case R.id.six:
                    section = type.get(5);
                    setButtonDrag(v);
                    break;
                case R.id.seven:
                    section = type.get(6);
                    setButtonDrag(v);
                    break;
                case R.id.eight:
                    section = type.get(7);
                    setButtonDrag(v);
                    break;
                case R.id.nine:
                    section = type.get(8);
                    setButtonDrag(v);
                default:
                    break;
            }
            return true;
        }
        return false;
    }

    private void setButtonDrag(View v) {
        ClipData data = ClipData.newPlainText("", "");
        View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
        v.startDrag(data, shadow, v, 0);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
